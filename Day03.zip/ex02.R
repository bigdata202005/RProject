rnorm(4)
rnorm(4, mean = 3)
rnorm(4, mean = 3, sd = 3)
y = rnorm(200)
hist(y)
y <- rnorm(200)
y
hist(y)
y = ceiling(y * 10)
y
hist(y)

