df1 = read.dcf('sample1.dcf')
df1
summary(df1)
