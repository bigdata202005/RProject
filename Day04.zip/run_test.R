require(testthat)
source("fibo.R")
test_dir("tests" , reporter="Summary" )