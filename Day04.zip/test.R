for(i in 1:10){
  cat(i, ' ')
}
print("")
for(i in 1:10){
  cat(i, ' ')
}
print("")

# source('fibo.R')
for(i in 1:10){
  cat(fibo(i), ' ')
}
print("")
