# pg_mean data set
library(gcookbook)

pg_mean
# group weight
# 1  ctrl  5.032
# 2  trt1  4.661
# 3  trt2  5.526

# geom_col() : 막대그래프
ggplot(pg_mean, aes(x = group, y = weight)) + geom_col()

# There's no entry for Time == 6
BOD
#>   Time demand
#> 1    1    8.3
#> 2    2   10.3
#> 3    3   19.0
#> 4    4   16.0
#> 5    5   15.6
#> 6    7   19.8

# Time is numeric (continuous)
str(BOD)
#> 'data.frame':    6 obs. of  2 variables:
#>  $ Time  : num  1 2 3 4 5 7
#>  $ demand: num  8.3 10.3 19 16 15.6 19.8
#>  - attr(*, "reference")= chr "A1.4, p. 270"


time1 = BOD$Time
class(time1)
str(time1)
is.vector(time1)
# 6까지 그려진다.
# x : 1 ~ 7
ggplot(BOD, aes(x = Time, y = demand)) + geom_col()

time_factor = factor(time1)
class(time_factor)
is.vector(time_factor)
# x축값을 팩터로 바꿔줘야 있는 값만 그려진다
ggplot(BOD, aes(x = time_factor, y = demand)) + geom_col()

# 한번에 처리가 가능하다 : 축값을 팩터로 바로적용
ggplot(BOD, aes(x = factor(Time), y = demand)) + geom_col()

# 테두리와 채움 색상지정
pg_mean
ggplot(pg_mean, aes(x = group, y = weight)) + geom_col(fill = "lightblue", colour = "black")


# Grouping Bars Together
cabbage_exp
ggplot(cabbage_exp, aes(x = Date, y = Weight, fill = Cultivar)) + geom_col(position = "dodge")
ggplot(cabbage_exp, aes(x = Date, y = Weight, fill = Cultivar)) + geom_col(position = "dodge") + scale_fill_brewer(palette = "Pastel1") 


